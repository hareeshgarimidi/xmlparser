package com.oracle.projecthandler;

import com.oracle.main.XmlStartingPoint;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


public class ProjectTag {
	//static String startingWithTarget=null;
	//Static String startingWithTarget=null;

	List<String> importStatement = new ArrayList<String>();
	/* identifyProjectTag is using for starting point of execution and TAG   */ 
	public static void identifyProjectTag(String actualPath) throws ParserConfigurationException, SAXException, IOException {
		File inputFile = new File(actualPath);
		String startingWithTarget=null;
		//List<String> importStatement = new ArrayList<String>();
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = (Document) dBuilder.parse(inputFile);
		doc.getDocumentElement().normalize();
		NodeList nList = doc.getElementsByTagName("project");
		for(int count=0; count<nList.getLength(); count++)
		{
			Node nNode = nList.item(count);
			Element eElement = (Element) nNode;
			startingWithTarget=eElement.getAttribute("default");
			System.out.println("starting target :"+startingWithTarget);
			XmlStartingPoint.startTargName = startingWithTarget;
			/* Collect  all import Statements from all dependency files */
		}
		
	}

}
