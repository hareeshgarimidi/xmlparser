package com.oracle.antbuild;

import java.io.BufferedReader;
import com.oracle.main.XmlStartingPoint;
import java.io.FileReader;
import java.io.IOException;

public class BuildStartsFrom {

	public static void buildFileInfo(String machine_name) throws IOException {
		String defFilePath="fusionapps\\intg\\fusionapps.def";
		String TotalPath=machine_name+defFilePath;
		//File startingXMLFolder = new File(TotalPath);
		BufferedReader br = new BufferedReader(new FileReader(TotalPath));
		String currentLine,path=null,name=null;
		while((currentLine = br.readLine()) != null)
		{
			if(currentLine.contains("    Family    =>    "))
			{
				System.out.println("line:"+currentLine);
				String family[]=currentLine.split("  ");
				//currentLine.replace("    Family    =>    ","");
				//currentLine.replace(" ", "");
				path="fusionapps\\"+family[family.length - 1]+"\\";
				name="build.xml";
			}
			else if(currentLine.contains("Ant_Build_File    =>    build-families.xml"))
			{
				path="fusionapps\\";
				name="build-families.xml";
			}
			else
			{
				continue;
			}
		}
		
		if(path !=null)
		{
			XmlStartingPoint.buildfilePath=path;
			XmlStartingPoint.buildfileName=name;
		}
		else{
			XmlStartingPoint.buildfilePath="fusionapps\\";
			XmlStartingPoint.buildfileName="build.xml";
		}
		br.close();
		
	}

}
