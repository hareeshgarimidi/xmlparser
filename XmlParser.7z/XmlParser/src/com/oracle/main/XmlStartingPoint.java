package com.oracle.main;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.oracle.antbuild.BuildStartsFrom;
import com.oracle.projecthandler.ProjectTag;
import com.oracle.parsing.StartParsing;

public class XmlStartingPoint {
	/* WE ARE USING MACHINE_NAME FOR STORING IN WHICH MACHINE BUILD IS GOING    */
	public static String machine_name;
	/* WE NEED TO GET THE  EXACT PATH FOR KNOWING THE WHERE TO START EXECUTION */
	public static String buildfilePath;
	/* WE NEED TO GET THE FILE NAME  TO PARSE  */
	public static String buildfileName;
	/* WE NEED ABSOLUTEPATH FOR FUTURE REFERENCE PURPOSE    */
	public static String absolutePath;
	/* WE ARE USING STARTING TARGET NAME OF BUILD  */
	public static String startTargName;
	/* WE NEED TO STORE ALL IMPORTED FILE STATEMENTS   */
	public static List<String> importedFiles=new ArrayList<String>();
	/* WE ARE USING fabuildtool for checking "fabuildtools.home"     */
	public static String fabuildtool="fabuildtools.home"; 
	/* WE ARE USING FUSIOAN APPS FOR CHECKING     */
	public static String fusionapps="fusionapps.home";
	/* WE ARE DECARING BASEDIRMAIN AND BASEDIR for IMPORT STATEMENT VALUES   */
	public static String BASEDIRMAIN="${main.basedir}";
	public static String  BASEDIR="${basedir}";
	/*  WE NEED TWO VARIABLES FOR IDENTIFYING FOLDER PATH THEY ARE FUSIONAPPS AND FABUILDTOOLS   */
	public static String fusionFolder="fusionapps";
	public static String fabuildFolder="fabuildtools";
		

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
		/* Get Machine path Where  "build is Happening"  ( WE TOOK THIS HARDCODED ONE FOR LOCAL PURPOSE)*/
		machine_name = "C:\\Users\\hgarimid\\Desktop\\fusionxmls\\";
		/*  Get buildfilePath $$ buildfileName fRom This Path   */
		BuildStartsFrom.buildFileInfo(machine_name);
		/*  IDENTIFY THE EXECUTION STARTING XML FROM SERIES   */
		absolutePath = machine_name+buildfilePath+buildfileName;
		/*   WE HAVE TO KNOW THE STARTING TARGET FROM BUILF FILE  FOR PARSING   */
		ProjectTag.identifyProjectTag(absolutePath);
		/*   WE NEED TO IDENTIFY  Starting Target File name  */
		StartParsing.parsingStarted();
	}
}
