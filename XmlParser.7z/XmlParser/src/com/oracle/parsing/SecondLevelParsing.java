package com.oracle.parsing;

import java.io.File;
import java.io.IOException;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.oracle.main.XmlStartingPoint;

public class SecondLevelParsing {

	

	public static void TargetSearch(String changedPath, String TargetName) throws ParserConfigurationException, SAXException, IOException {
		File inputFile = new File(changedPath);
		System.out.println("path of Executed xml:"+changedPath);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = (Document) dBuilder.parse(inputFile);
		doc.getDocumentElement().normalize();
		NodeList nList = doc.getElementsByTagName("target");
		boolean targetFounded = false;
		for(int count=0; count<nList.getLength(); count++)
		{
			Node nNode = nList.item(count);
			Element eElement = (Element) nNode;
			if((eElement.getAttribute("name")).equals(TargetName))
			{
				targetFounded= true;
				System.out.println("2nd level hareesh"+"TARGET NAME:"+eElement.getAttribute("name")+"DEPENDS : "+eElement.getAttribute("depends"));
				break;
			}
			else
			{
				System.out.println("2nd level garimidi hareesh");
			}
		}
		if(targetFounded== false)
		{
			String relativePath= baseDirectory(changedPath);
			NodeList importList = doc.getElementsByTagName("import");
			for(int count=0;count < importList.getLength();count++)
			{
				Node nNode = importList.item(count);
				Element eElement = (Element) nNode;
				String filePathofNode=eElement.getAttribute("file");
				String changedPath1= ChangePathform(filePathofNode,relativePath);
				System.out.println("path to search  :  "+changedPath1);
				TargetSearch(changedPath,TargetName);
			}
		}
	}

	private static String baseDirectory(String changedPath) {
		String foldersnames[]=changedPath.split(Pattern.quote("\\"));
		String bsedirpath=null;
		for(String fname : foldersnames)
		{
			if(fname.contains(".xml"))
			{
				continue;
			}
			else
			{
				if(bsedirpath == null)
				{
					bsedirpath = fname+"\\";
				}
				else{
					bsedirpath.concat(fname+"\\");
				}
				
			}
		}
		return bsedirpath;
	}

	private static String ChangePathform(String filePathofNode,String relativePath) {
		
		String partsofpath[]=filePathofNode.split(Pattern.quote("/"));
		//String actualfilePath=relativePath;
		String pathfull=relativePath;
		for(int i=0; i < partsofpath.length; i++ )
		{
			if(partsofpath[i].contains("basedir"))
			{
				
			}
			else if(partsofpath[i].contains(".."))
			{
				System.out.println("garimidi garimidi garimidi");
				
				String pathElements[]=pathfull.split(Pattern.quote("\\"));
				String newPath = null;
				for(int pos=0; pos < (pathElements.length)-1; pos++)
				{
					if(newPath == null)
					{
						newPath=pathElements[pos]+"\\";
					}
					else
					{
						newPath=newPath.concat(pathElements[pos]+"\\");
					}
				}
				pathfull=newPath;
			}
			else if(partsofpath[i].contains("fabuildtools.home"))
			{
				pathfull=XmlStartingPoint.machine_name+"fabuildtools\\";
			}
			else if (i+1 < partsofpath.length)
			{
				pathfull+=partsofpath[i]+"\\";
			}
			else{
				
				pathfull+=partsofpath[i];
			}
		}
		return pathfull;
	}

}
